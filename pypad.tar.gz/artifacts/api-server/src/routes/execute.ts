import { Router, type IRouter } from "express";
import { spawn } from "child_process";
import { ExecuteCodeBody, ExecuteCodeResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const TIMEOUT_MS = 10000;

router.post("/execute", async (req, res): Promise<void> => {
  const parsed = ExecuteCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { code } = parsed.data;

  const start = Date.now();

  try {
    const result = await runPython(code, TIMEOUT_MS);
    const durationMs = Date.now() - start;

    req.log.info({ exitCode: result.exitCode, durationMs }, "Code execution complete");

    res.json(
      ExecuteCodeResponse.parse({
        stdout: result.stdout,
        stderr: result.stderr,
        exitCode: result.exitCode,
        durationMs,
      })
    );
  } catch (err: unknown) {
    const durationMs = Date.now() - start;
    if (err instanceof Error && err.message === "TIMEOUT") {
      req.log.warn({ durationMs }, "Code execution timed out");
      res.json(
        ExecuteCodeResponse.parse({
          stdout: "",
          stderr: `Execution timed out after ${TIMEOUT_MS / 1000} seconds.`,
          exitCode: 124,
          durationMs,
        })
      );
      return;
    }
    req.log.error({ err }, "Code execution error");
    res.status(500).json({ error: "Internal server error" });
  }
});

function runPython(
  code: string,
  timeoutMs: number
): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  return new Promise((resolve, reject) => {
    const child = spawn("python3", ["-c", code], {
      timeout: timeoutMs,
      env: {
        ...process.env,
        PYTHONDONTWRITEBYTECODE: "1",
        PYTHONUNBUFFERED: "1",
      },
    });

    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString();
    });

    child.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString();
    });

    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("TIMEOUT"));
    }, timeoutMs);

    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({
        stdout,
        stderr,
        exitCode: code ?? 1,
      });
    });

    child.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

export default router;
