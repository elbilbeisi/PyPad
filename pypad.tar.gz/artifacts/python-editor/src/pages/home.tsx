import React, { useState, useRef, useEffect, useCallback } from "react";
import Editor from "@monaco-editor/react";
import { Play, RotateCcw, AlertCircle, CheckCircle2, Clock, Terminal, Copy, Check } from "lucide-react";
import { useExecuteCode, useHealthCheck } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

const EXAMPLES = {
  hello: `print("Hello, PyPad!")\n\n# A simple loop\nfor i in range(3):\n    print(f"Counting: {i}")`,
  fibonacci: `def fibonacci(n):\n    if n <= 0:\n        return []\n    elif n == 1:\n        return [0]\n    \n    seq = [0, 1]\n    while len(seq) < n:\n        seq.append(seq[-1] + seq[-2])\n    return seq\n\nprint("First 10 Fibonacci numbers:")\nprint(fibonacci(10))`,
  list_comp: `# List comprehensions and dicts\nsquares = [x**2 for x in range(10)]\nprint(f"Squares: {squares}")\n\nevens = {x: x**2 for x in range(10) if x % 2 == 0}\nprint(f"Even squares dict:\\n{evens}")`,
};

export default function Home() {
  const [code, setCode] = useState(EXAMPLES.hello);
  const [output, setOutput] = useState<{ stdout: string; stderr: string; exitCode: number | null; durationMs: number | null }>({
    stdout: "",
    stderr: "",
    exitCode: null,
    durationMs: null,
  });

  const executeCode = useExecuteCode();
  const { data: healthStatus } = useHealthCheck();

  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  const handleRunCode = useCallback(() => {
    if (executeCode.isPending) return;
    
    setOutput({ stdout: "", stderr: "", exitCode: null, durationMs: null });
    
    executeCode.mutate(
      { data: { code } },
      {
        onSuccess: (result) => {
          setOutput({
            stdout: result.stdout,
            stderr: result.stderr,
            exitCode: result.exitCode,
            durationMs: result.durationMs,
          });
        },
        onError: (error: any) => {
          setOutput((prev) => ({
            ...prev,
            stderr: error?.message || "An unknown error occurred during execution.",
            exitCode: 1
          }));
        }
      }
    );
  }, [code, executeCode]);

  const handleEditorKeyDown = useCallback((e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleRunCode();
    }
  }, [handleRunCode]);

  const [copied, setCopied] = useState(false);

  const handleCopyCode = useCallback(() => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [code]);

  const handleLoadExample = (value: keyof typeof EXAMPLES) => {
    setCode(EXAMPLES[value]);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-[#0d0d0f] text-gray-300 font-sans overflow-hidden">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-[#2d2d30] bg-[#111114]">
        <div className="flex items-center space-x-3">
          <Terminal className="w-5 h-5 text-blue-400" />
          <h1 className="text-lg font-bold text-gray-100 tracking-tight">PyPad</h1>
          {healthStatus && (
            <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20 text-xs py-0 h-5">
              API {healthStatus.status}
            </Badge>
          )}
        </div>
        
        <div className="flex items-center space-x-4">
          <Select onValueChange={handleLoadExample}>
            <SelectTrigger className="w-[180px] h-8 bg-[#1e1e22] border-[#2d2d30] text-xs">
              <SelectValue placeholder="Load Example..." />
            </SelectTrigger>
            <SelectContent className="bg-[#1e1e22] border-[#2d2d30] text-gray-300">
              <SelectItem value="hello">Hello World</SelectItem>
              <SelectItem value="fibonacci">Fibonacci</SelectItem>
              <SelectItem value="list_comp">List Comprehension</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            onClick={handleRunCode} 
            disabled={executeCode.isPending}
            className="h-8 bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs px-4"
          >
            {executeCode.isPending ? (
              <span className="flex items-center"><div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" /> Running...</span>
            ) : (
              <span className="flex items-center"><Play className="w-3 h-3 mr-2" /> Run Code <span className="opacity-50 ml-2 font-mono text-[10px]">⌘Enter</span></span>
            )}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-col lg:flex-row flex-1 overflow-hidden">
        {/* Editor */}
        <div className="flex-1 border-b lg:border-b-0 lg:border-r border-[#2d2d30] flex flex-col relative" onKeyDown={handleEditorKeyDown}>
          <div className="h-8 bg-[#111114] border-b border-[#2d2d30] flex items-center justify-between px-4">
            <span className="text-xs font-mono text-gray-400">main.py</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-gray-400 hover:text-white hover:bg-[#2d2d30]"
              onClick={handleCopyCode}
              title="Copy Code"
            >
              {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
            </Button>
          </div>
          <div className="flex-1 w-full bg-[#1e1e1e]">
            <Editor
              height="100%"
              defaultLanguage="python"
              theme="vs-dark"
              value={code}
              onChange={(value) => setCode(value || "")}
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                fontFamily: "'JetBrains Mono', 'Menlo', 'Monaco', 'Courier New', monospace",
                lineHeight: 1.5,
                padding: { top: 16 },
                scrollBeyondLastLine: false,
                smoothScrolling: true,
                cursorBlinking: "smooth",
                wordWrap: "on",
                renderLineHighlight: "all",
              }}
            />
          </div>
        </div>

        {/* Output Panel */}
        <div className="h-1/3 lg:h-full lg:w-[450px] xl:w-[550px] bg-[#111114] flex flex-col">
          <div className="h-8 border-b border-[#2d2d30] flex items-center justify-between px-4 shrink-0">
            <span className="text-xs font-medium uppercase tracking-wider text-gray-500">Output</span>
            <div className="flex items-center space-x-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 text-gray-400 hover:text-white hover:bg-[#2d2d30]"
                onClick={() => setOutput({ stdout: "", stderr: "", exitCode: null, durationMs: null })}
                title="Clear Output"
              >
                <RotateCcw className="w-3 h-3" />
              </Button>
            </div>
          </div>
          
          <ScrollArea className="flex-1 bg-[#0a0a0c]">
            <div className="p-4 font-mono text-[13px] leading-relaxed">
              {executeCode.isPending ? (
                <div className="text-gray-500 italic animate-pulse">Executing...</div>
              ) : output.exitCode === null && !output.stdout && !output.stderr ? (
                <div className="text-gray-600 italic">Ready. Press Run to execute.</div>
              ) : (
                <div className="space-y-4">
                  {output.stdout && (
                    <div className="whitespace-pre-wrap text-gray-300 break-all">{output.stdout}</div>
                  )}
                  {output.stderr && (
                    <div className="whitespace-pre-wrap text-red-400 break-all">{output.stderr}</div>
                  )}
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Execution Metadata */}
          {output.exitCode !== null && (
            <div className="h-10 border-t border-[#2d2d30] bg-[#111114] px-4 flex items-center space-x-6 text-xs shrink-0">
              <div className="flex items-center space-x-1.5">
                <span className="text-gray-500">Status:</span>
                {output.exitCode === 0 ? (
                  <span className="flex items-center text-green-400"><CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Success (0)</span>
                ) : (
                  <span className="flex items-center text-red-400"><AlertCircle className="w-3.5 h-3.5 mr-1" /> Error ({output.exitCode})</span>
                )}
              </div>
              {output.durationMs !== null && (
                <div className="flex items-center space-x-1.5">
                  <span className="text-gray-500">Time:</span>
                  <span className="flex items-center text-gray-300"><Clock className="w-3.5 h-3.5 mr-1 text-gray-500" /> {output.durationMs}ms</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}