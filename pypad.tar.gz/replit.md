# PyPad

A Python code playground that lets you write and run Python 3.12 code directly in the browser, with syntax highlighting, live output, and example snippets.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/python-editor run dev` — run the frontend (port 19088)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Monaco Editor (`@monaco-editor/react`), shadcn/ui
- API: Express 5
- Validation: Zod (`zod/v4`)
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Python runtime: Python 3.12 (installed as Replit module)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract source of truth
- `artifacts/python-editor/src/pages/home.tsx` — main editor UI
- `artifacts/api-server/src/routes/execute.ts` — Python code execution route
- `lib/api-client-react/src/generated/` — generated React Query hooks
- `lib/api-zod/src/generated/` — generated Zod schemas

## Architecture decisions

- Code execution runs server-side via `child_process.spawn("python3", ["-c", code])` with a 10-second timeout and SIGKILL on timeout
- Contract-first API: OpenAPI spec → Orval codegen → typed hooks + Zod schemas
- Dark theme enforced globally via `document.documentElement.classList.add("dark")` in the home page
- Frontend routes through the shared proxy at `/` (port 19088), API at `/api` (port 8080)

## Product

- Monaco Editor with Python 3.12 syntax highlighting
- Run button + Ctrl+Enter shortcut to execute code
- Output panel showing stdout (white) and stderr (red) with exit code and duration
- Copy button in the editor tab bar (turns green checkmark on success)
- Preloaded examples: Hello World, Fibonacci, List Comprehension
- 10-second execution timeout to prevent infinite loops

## User preferences

- User wants to keep PyPad available for repeated future use — deploy it.

## Gotchas

- Python 3.12 is installed as a Replit module; the binary is `python3`
- `monaco-editor` must be installed as a peer alongside `@monaco-editor/react`
- Do not run `pnpm dev` at workspace root — start workflows individually via the workflow runner

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
